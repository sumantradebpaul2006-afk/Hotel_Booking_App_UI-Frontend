package com.example.hotelstay.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.compose.ui.tooling.preview.Preview

data class FAQItem(val question: String, val answer: String)

@Preview(showBackground = true)
@Composable
fun FAQScreenPreview() {
    FAQScreen()
}

@Composable
fun FAQScreen() {
    val faqs = listOf(
        FAQItem(
            "How do I book a hotel?",
            "To book a hotel, browse through our available hotels on the Home screen, select your preferred one, and follow the instructions to complete your booking."
        ),
        FAQItem(
            "Can I cancel my booking?",
            "Yes, you can cancel your booking through the 'My Bookings' section. Please check the cancellation policy of the specific hotel for any potential fees."
        ),
        FAQItem(
            "What payment methods are accepted?",
            "We accept major credit/debit cards, UPI, and net banking for all bookings."
        ),
        FAQItem(
            "Is breakfast included?",
            "Breakfast inclusion varies by hotel and room type. You can find this information in the hotel details before booking."
        ),
        FAQItem(
            "How do I get my booking confirmation?",
            "Once your booking is successful, you will receive a confirmation email and SMS with all the details. You can also view it in the app."
        ),
        FAQItem(
            "What is the check-in and check-out time?",
            "Standard check-in time is 2:00 PM and check-out time is 11:00 AM. However, this may vary by hotel. Please check the hotel policy during booking."
        ),
        FAQItem(
            "Do you offer airport shuttle services?",
            "Many of our partner hotels offer airport shuttle services. You can check for this facility under the 'Amenities' section of the hotel details."
        ),
        FAQItem(
            "Are pets allowed?",
            "Pet policies vary by hotel. Some hotels are pet-friendly while others are not. You can filter hotels by 'Pet Friendly' or check the hotel's specific policy."
        )
    )

    Column(modifier = Modifier.padding(24.dp)) {
        Text(
            text = "Frequently Asked Questions",
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(bottom = 20.dp)
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(faqs) { faq ->
                FAQCard(faq)
            }
        }
    }
}

@Composable
fun FAQCard(faq: FAQItem) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { expanded = !expanded }
            .animateContentSize(),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = faq.question,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null
                )
            }
            if (expanded) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = faq.answer,
                    fontSize = 16.sp,
                    color = Color.DarkGray,
                    lineHeight = 22.sp
                )
            }
        }
    }
}
