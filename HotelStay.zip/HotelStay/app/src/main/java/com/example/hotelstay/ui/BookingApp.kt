package com.example.hotelstay.ui

import androidx.compose.runtime.Composable

@Composable
fun BookingApp(){
    AppNavigation()
}