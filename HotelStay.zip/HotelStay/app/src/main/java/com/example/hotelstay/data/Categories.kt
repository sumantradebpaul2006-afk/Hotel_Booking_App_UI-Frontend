package com.example.hotelstay.data

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Categories (
    @StringRes val stringResourceId: Int,
    @DrawableRes val imageResourceId: Int,
    val price: String,
    val isAvailable: Boolean = true
)
