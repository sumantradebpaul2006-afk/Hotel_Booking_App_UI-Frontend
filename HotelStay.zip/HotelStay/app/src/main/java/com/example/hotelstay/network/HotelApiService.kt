package com.example.hotelstay.network

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

private const val BASE_URL = "https://raw.githubusercontent.com/Sumantra001/HotelStay/main/"

private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

private val retrofit = Retrofit.Builder()
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .baseUrl(BASE_URL)
    .build()

interface HotelApiService {
    @GET("places.json")
    suspend fun getPlaces(): List<Place>
}

object HotelApi {
    val retrofitService: HotelApiService by lazy {
        retrofit.create(HotelApiService::class.java)
    }
}
