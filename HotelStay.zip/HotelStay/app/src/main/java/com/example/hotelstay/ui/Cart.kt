package com.example.hotelstay.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    hotelViewModel: HotelViewModel,
    onBackClick: () -> Unit
) {
    val selectedHotel by hotelViewModel.selectedHotel.collectAsState()
    val roomType by hotelViewModel.roomType.collectAsState()
    val roomCount by hotelViewModel.count.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Booking Details") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            selectedHotel?.let { hotel ->
                Text(
                    text = stringResource(hotel.stringResourceId),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF42A5F5)
                )
                Spacer(modifier = Modifier.height(16.dp))

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Room Type", fontWeight = FontWeight.Bold)
                        Row {
                            RadioButton(
                                selected = roomType == "Regular",
                                onClick = { hotelViewModel.setRoomType("Regular") }
                            )
                            Text("Regular", modifier = Modifier.align(Alignment.CenterVertically))
                            Spacer(modifier = Modifier.width(16.dp))
                            RadioButton(
                                selected = roomType == "Premium",
                                onClick = { hotelViewModel.setRoomType("Premium") }
                            )
                            Text("Premium", modifier = Modifier.align(Alignment.CenterVertically))
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text("Number of Rooms", fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { if (roomCount > 1) hotelViewModel.setCount(roomCount - 1) }) {
                                Text("-")
                            }
                            Text("$roomCount", modifier = Modifier.padding(horizontal = 16.dp), fontSize = 18.sp)
                            Button(onClick = { hotelViewModel.setCount(roomCount + 1) }) {
                                Text("+")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                val basePrice = remember(hotel.price) { hotel.price.replace(Regex("[^0-9]"), "").toLongOrNull() ?: 0L }
                val total = remember(basePrice, roomType, roomCount) {
                    val singleRoomPrice = if (roomType == "Premium") (basePrice * 1.5).toLong() else basePrice
                    singleRoomPrice * roomCount
                }
                val singleRoomPrice = if (roomType == "Premium") (basePrice * 1.5).toLong() else basePrice

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Price Details",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Room Price ($roomType)")
                            Text("Rs. $singleRoomPrice")
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Number of Rooms")
                            Text("x $roomCount")
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Amount", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text("Rs. $total", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF2E7D32))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = { /* Confirm Booking */ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF42A5F5))
                ) {
                    Text("CONFIRM BOOKING", color = Color.White)
                }
            } ?: Text("No hotel selected")
        }
    }
}
