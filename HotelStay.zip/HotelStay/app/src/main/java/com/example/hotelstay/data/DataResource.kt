package com.example.hotelstay.data

import com.example.hotelstay.R

object DataResource {
    fun loadCategories(): List<Categories> {
        return listOf(
            Categories(R.string.hotel_1, R.drawable.hotel_1, "Rs. 5000"),
            Categories(R.string.hotel_2, R.drawable.hotel_2, "Rs. 6000"),
            Categories(R.string.hotel_3, R.drawable.hotel_3, "Rs. 7000"),
            Categories(R.string.hotel_4, R.drawable.hotel_4, "Rs. 8000"),
            Categories(R.string.hotel_5, R.drawable.hotel_1, "Rs. 5500") // Using hotel_1 as fallback
        )
    }
}
