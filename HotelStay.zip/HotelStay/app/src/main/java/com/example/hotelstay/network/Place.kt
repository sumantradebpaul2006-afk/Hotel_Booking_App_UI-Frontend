package com.example.hotelstay.network

data class Place(
    val name: String,
    val imageUrl: String,
    val description: String
)
