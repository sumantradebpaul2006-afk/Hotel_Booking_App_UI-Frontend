package com.example.hotelstay.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hotelstay.network.HotelApi
import com.example.hotelstay.network.Place
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HotelViewModel : ViewModel() {
    private val _checkIn = MutableStateFlow("")
    val checkIn: StateFlow<String> = _checkIn.asStateFlow()

    private val _checkOut = MutableStateFlow("")
    val checkOut: StateFlow<String> = _checkOut.asStateFlow()

    private val _count = MutableStateFlow(1)
    val count: StateFlow<Int> = _count.asStateFlow()

    private val _bedFlag = MutableStateFlow(false)
    val bedFlag: StateFlow<Boolean> = _bedFlag.asStateFlow()

    private val _places = MutableStateFlow<List<Place>>(emptyList())
    val places: StateFlow<List<Place>> = _places.asStateFlow()

    private val _selectedHotel = MutableStateFlow<com.example.hotelstay.data.Categories?>(null)
    val selectedHotel: StateFlow<com.example.hotelstay.data.Categories?> = _selectedHotel.asStateFlow()

    private val _roomType = MutableStateFlow("Regular")
    val roomType: StateFlow<String> = _roomType.asStateFlow()

    fun selectHotel(hotel: com.example.hotelstay.data.Categories) {
        _selectedHotel.value = hotel
    }

    fun setRoomType(type: String) {
        _roomType.value = type
    }

    fun calculateTotal(basePrice: Long): Long {
        val singleRoomPrice = if (_roomType.value == "Premium") (basePrice * 1.5).toLong() else basePrice
        return singleRoomPrice * _count.value
    }

    init {
        getHotelPlaces()
    }

    private fun getHotelPlaces() {
        viewModelScope.launch {
            try {
                _places.value = HotelApi.retrofitService.getPlaces()
            } catch (e: Exception) {
                _places.value = emptyList()
            }
        }
    }

    fun setCheckIn(date: String) {
        _checkIn.value = date
    }

    fun setCheckOut(date: String) {
        _checkOut.value = date
    }

    fun setCount(newCount: Int) {
        _count.value = newCount
    }

    fun setBedFlag(flag: Boolean) {
        _bedFlag.value = flag
    }
}
