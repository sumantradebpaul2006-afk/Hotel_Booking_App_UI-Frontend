package com.example.hotelstay.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.hotelstay.R

enum class BookingScreen {
    SignUp,
    Verification,
    Home,
    Where2Go,
    FAQs,
    Cart
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val hotelViewModel: HotelViewModel = viewModel()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val startDestination = BookingScreen.SignUp.name

    val showBottomBar = currentDestination?.route in listOf(
        BookingScreen.Home.name,
        BookingScreen.Where2Go.name,
        BookingScreen.FAQs.name
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = Color.Transparent,
                    modifier = Modifier.background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF42A5F5), Color(0xFF26C6DA))
                        )
                    )
                ) {
                    val items = listOf(
                        Triple(BookingScreen.Home.name, R.string.home, Icons.Default.Home),
                        Triple(BookingScreen.Where2Go.name, R.string.where2go, Icons.Default.LocationOn),
                        Triple(BookingScreen.FAQs.name, R.string.faqs, Icons.Default.Info)
                    )

                    items.forEach { (route, labelId, icon) ->
                        NavigationBarItem(
                            icon = { Icon(icon, contentDescription = null, tint = Color.White) },
                            label = { Text(stringResource(labelId), color = Color.White) },
                            selected = currentDestination?.hierarchy?.any { it.route == route } == true,
                            onClick = {
                                navController.navigate(route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.White.copy(alpha = 0.2f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(route = BookingScreen.SignUp.name) {
                SignUpScreen(
                    hotelViewModel = hotelViewModel,
                    onOtpSent = {
                        navController.navigate(BookingScreen.Verification.name)
                    },
                    onAutoSignIn = {
                        navController.navigate(BookingScreen.Home.name) {
                            popUpTo(BookingScreen.SignUp.name) { inclusive = true }
                        }
                    }
                )
            }
            composable(route = BookingScreen.Verification.name) {
                VerificationScreen(
                    hotelViewModel = hotelViewModel,
                    onVerifyClick = {
                        navController.navigate(BookingScreen.Home.name) {
                            popUpTo(BookingScreen.SignUp.name) { inclusive = true }
                        }
                    }
                )
            }
            composable(route = BookingScreen.Home.name) {
                StartScreen(
                    onHotelClick = { hotel ->
                        hotelViewModel.selectHotel(hotel)
                        navController.navigate(BookingScreen.Cart.name)
                    }
                )
            }
            composable(route = BookingScreen.Where2Go.name) {
                Where2GoScreen(
                    hotelViewModel = hotelViewModel,
                    onLogoutClick = {
                        navController.navigate(BookingScreen.SignUp.name) {
                            popUpTo(0)
                        }
                    }
                )
            }
            composable(route = BookingScreen.FAQs.name) {
                FAQScreen()
            }
            composable(route = BookingScreen.Cart.name) {
                CartScreen(
                    hotelViewModel = hotelViewModel,
                    onBackClick = { navController.popBackStack() }
                )
            }
        }
    }
}
